<?php

/* custom PHP functions below this line */

add_filter( 'woocommerce_order_number', 'webendev_woocommerce_order_number', 1, 2 );
/**
 * Add Prefix to WooCommerce Order Number
 * 
 */
function webendev_woocommerce_order_number( $oldnumber, $order ) {
	return 'EC' . $order->id;
}

function wc_xml_export_suite_export_order_on_payment( $order_id ) {

$export = new WC_Customer_Order_XML_Export_Suite_Handler( $order_id );

// for FTP
$export->upload();

// uncomment for HTTP POST
// $export->http_post();
}
add_action( 'woocommerce_payment_complete', 'wc_xml_export_suite_export_order_on_payment' );

?>