<?php

/* custom PHP functions below this line */

add_filter( 'woocommerce_order_number', 'webendev_woocommerce_order_number', 1, 2 );
/**
 * Add Prefix to WooCommerce Order Number
 * 
 */
function webendev_woocommerce_order_number( $oldnumber, $order ) {
	return 'EC' . $order->id;
}

function wc_xml_export_suite_export_order_on_payment( $order_id ) {

$export = new WC_Customer_Order_XML_Export_Suite_Handler( $order_id );

// for FTP
$export->upload();

// uncomment for HTTP POST
// $export->http_post();
}
add_action( 'woocommerce_payment_complete', 'wc_xml_export_suite_export_order_on_payment' );

/**
 * Hide ALL shipping options when free shipping is available and customer is NOT in certain states
 * Hide Free Shipping if customer IS in those states
 *
 * UPDATED FOR WOOCOMMERCE 2.1
 *
 * Change $excluded_states = array( 'AK','HI' ); to include all the states that DO NOT have free shipping
 */
add_filter( 'woocommerce_package_rates', 'hide_all_shipping_when_free_is_available' , 10, 2 );

/**
 * Hide ALL Shipping option when free shipping is available
 *
 * @param array $available_methods
 */
function hide_all_shipping_when_free_is_available( $rates, $package ) {
 
	$excluded_states = array( 'AK','HI' );
	if( isset( $rates['free_shipping'] ) AND !in_array( WC()->customer->shipping_state, $excluded_states ) ) :
		// Get Free Shipping array into a new array
		$freeshipping = array();
		$freeshipping = $rates['free_shipping'];
 
		// Empty the $available_methods array
		unset( $rates );
 
		// Add Free Shipping back into $avaialble_methods
		$rates = array();
		$rates[] = $freeshipping;
 
	endif;
 
	if( isset( $rates['free_shipping'] ) AND in_array( WC()->customer->shipping_state, $excluded_states ) ) {
 
		// remove free shipping option
		unset( $rates['free_shipping'] );
 
	}

	return $rates;
}

add_filter( 'woocommerce_package_rates', 'hide_shipping_when_free_is_available', 10, 2 );

// Remove all currency symbols
function sww_remove_wc_currency_symbols( $currency_symbol, $currency ) {
     $currency_symbol = '';
     return $currency_symbol;
}
add_filter('woocommerce_currency_symbol', 'sww_remove_wc_currency_symbols', 10, 2);

/**
 * Hide shipping rates when free shipping is available
 *
 * @param array $rates Array of rates found for the package
 * @param array $package The package array/object being shipped
 * @return array of modified rates
 */
function hide_shipping_when_free_is_available( $rates, $package ) {
 	
 	// Only modify rates if free_shipping is present
  	if ( isset( $rates['free_shipping'] ) ) {
  	
  		// To unset a single rate/method, do the following. This example unsets flat_rate shipping
  		unset( $rates['flat_rate'] );
  		
  		// To unset all methods except for free_shipping, do the following
  		$free_shipping          = $rates['free_shipping'];
  		$rates                  = array();
  		$rates['free_shipping'] = $free_shipping;
	}
	return $rates;
}

/**
 * Maxlength billing address 25
 */

add_action("wp_footer", "cod_set_max_length");

function cod_set_max_length(){
if( !is_checkout())
   return;
?>
<script>
jQuery(document).ready(function($){
      $("#billing_company").attr('maxlength','25');
      $("#billing_address_1").attr('maxlength','25');
      $("#billing_address_2").attr('maxlength','25');
      $("#shipping_company").attr('maxlength','25');
      $("#shipping_address_1").attr('maxlength','25');
      $("#shipping_address_2").attr('maxlength','25');

});
</script>
<?php
}

?>